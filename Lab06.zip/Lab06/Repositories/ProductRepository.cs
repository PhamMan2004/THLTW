﻿using Lab06.Model;
using Lab06.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Lab06.Repositories
{
    public class ProductRepository : IProductRepository
    {
        private readonly ApplicationDbContext _context;

        // Constructor để inject ApplicationDbContext vào repository
        public ProductRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        // Lấy tất cả sản phẩm từ cơ sở dữ liệu
        public async Task<IEnumerable<Product>> GetProductsAsync()
        {
            return await _context.Products.ToListAsync();
        }

        // Lấy sản phẩm theo ID
        public async Task<Product> GetProductByIdAsync(int id)
        {
            return await _context.Products.FindAsync(id);
        }

        // Thêm một sản phẩm mới vào cơ sở dữ liệu
        public async Task AddProductAsync(Product product)
        {
            await _context.Products.AddAsync(product);
            await _context.SaveChangesAsync();
        }

        // Cập nhật thông tin sản phẩm
        public async Task UpdateProductAsync(Product product)
        {
            _context.Entry(product).State = EntityState.Modified;  // Đánh dấu đối tượng là đã được thay đổi
            await _context.SaveChangesAsync();
        }

        // Xóa sản phẩm theo ID
        public async Task DeleteProductAsync(int id)
        {
            var product = await _context.Products.FindAsync(id);  // Tìm sản phẩm theo ID
            if (product != null)  // Nếu tìm thấy sản phẩm
            {
                _context.Products.Remove(product);  // Xóa sản phẩm khỏi DbSet
                await _context.SaveChangesAsync();  // Lưu thay đổi vào cơ sở dữ liệu
            }
        }
    }
}
