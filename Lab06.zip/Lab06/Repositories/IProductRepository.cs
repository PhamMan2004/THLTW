﻿using Lab06.Model;
using Lab06.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Lab06.Repositories
{
    public interface IProductRepository
    {
        Task<IEnumerable<Product>> GetProductsAsync();  // Lấy tất cả sản phẩm
        Task<Product> GetProductByIdAsync(int id);  // Lấy sản phẩm theo ID
        Task AddProductAsync(Product product);  // Thêm sản phẩm mới
        Task UpdateProductAsync(Product product);  // Cập nhật sản phẩm
        Task DeleteProductAsync(int id);  // Xóa sản phẩm theo ID
    }
}
