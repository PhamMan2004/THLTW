﻿using Lab06.Model;
using Lab06.Models;
using Lab06.Repositories;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

namespace Lab06.Controllers
{
    [ApiController]
    [Route("api/products")]
    public class ProductApiController : ControllerBase
    {
        private readonly IProductRepository _productRepository;

        // Constructor để inject IProductRepository vào controller
        public ProductApiController(IProductRepository productRepository)
        {
            _productRepository = productRepository;
        }

        // Lấy tất cả sản phẩm
        [HttpGet]
        public async Task<IActionResult> GetProducts()
        {
            try
            {
                var products = await _productRepository.GetProductsAsync();
                return Ok(products);  // Trả về mã trạng thái 200 OK kèm theo danh sách sản phẩm
            }
            catch (Exception ex)
            {
                // Xử lý lỗi
                return StatusCode(500, "Internal server error");  // Trả về mã lỗi 500
            }
        }

        // Lấy sản phẩm theo ID
        [HttpGet("{id}")]
        public async Task<IActionResult> GetProductById(int id)
        {
            try
            {
                var product = await _productRepository.GetProductByIdAsync(id);
                if (product == null)
                {
                    return NotFound();  // Trả về mã lỗi 404 nếu không tìm thấy sản phẩm
                }
                return Ok(product);  // Trả về mã trạng thái 200 OK kèm theo thông tin sản phẩm
            }
            catch (Exception ex)
            {
                // Xử lý lỗi
                return StatusCode(500, "Internal server error");  // Trả về mã lỗi 500
            }
        }

        // Thêm sản phẩm mới
        [HttpPost]
        public async Task<IActionResult> AddProduct([FromBody] Product product)
        {
            try
            {
                // Gọi repository để thêm sản phẩm vào cơ sở dữ liệu
                await _productRepository.AddProductAsync(product);

                // Trả về thông tin của sản phẩm vừa thêm, bao gồm ID được sinh tự động
                return CreatedAtAction(nameof(GetProductById), new { id = product.Id }, product);
            }
            catch (Exception ex)
            {
                // Log lỗi hoặc xử lý lỗi chi tiết ở đây nếu cần
                return StatusCode(500, "Internal server error");
            }
        }


        // Cập nhật sản phẩm
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateProduct(int id, [FromBody] Product product)
        {
            try
            {
                if (id != product.Id)
                {
                    return BadRequest();  // Trả về lỗi 400 nếu ID trong URL không khớp với ID của sản phẩm
                }

                await _productRepository.UpdateProductAsync(product);
                return NoContent();  // Trả về mã trạng thái 204 No Content nếu cập nhật thành công
            }
            catch (Exception ex)
            {
                // Xử lý lỗi
                return StatusCode(500, "Internal server error");  // Trả về mã lỗi 500
            }
        }

        // Xóa sản phẩm
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteProduct(int id)
        {
            try
            {
                await _productRepository.DeleteProductAsync(id);
                return NoContent();  // Trả về mã trạng thái 204 No Content nếu xóa thành công
            }
            catch (Exception ex)
            {
                // Xử lý lỗi
                return StatusCode(500, "Internal server error");  // Trả về mã lỗi 500
            }
        }
    }
}
