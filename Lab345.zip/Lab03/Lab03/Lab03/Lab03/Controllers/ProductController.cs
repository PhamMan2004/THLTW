﻿using Lab03.Models;
using Lab03.Repository;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Threading.Tasks;
using System.IO;
using Microsoft.AspNetCore.Identity;

namespace Lab03.Controllers
{
    public class ProductController : BaseController
    {
        private readonly IProductRepository _productRepository;
        private readonly ICategoryRepository _categoryRepository;

        public ProductController(IProductRepository productRepository, ICategoryRepository categoryRepository,
                                 UserManager<ApplicationUser> userManager, SignInManager<ApplicationUser> signInManager)
            : base(userManager, signInManager)  // Kế thừa từ BaseController
        {
            _productRepository = productRepository;
            _categoryRepository = categoryRepository;
        }

        public async Task<IActionResult> Index(string? searchString, int? categoryId)
        {
            var products = await _productRepository.GetAllAsync();
            var categories = await _categoryRepository.GetAllAsync();

            // Lọc theo danh mục nếu có
            if (categoryId.HasValue)
            {
                products = products
                    .Where(p => p.CategoryId == categoryId.Value)
                    .ToList();
            }

            // Tìm kiếm theo tên sản phẩm (không phân biệt hoa thường)
            if (!string.IsNullOrWhiteSpace(searchString))
            {
                searchString = searchString.Trim().ToLower();
                products = products
                    .Where(p => !string.IsNullOrEmpty(p.Name_) && p.Name_.ToLower().Contains(searchString))
                    .ToList();
            }

            // Gán tên danh mục cho từng sản phẩm
            foreach (var product in products)
            {
                var category = categories.FirstOrDefault(c => c.Id == product.CategoryId);
                product.CategoryName = category?.Name_ ?? "Không có";
            }

            ViewBag.Categories = categories;
            ViewBag.IsAdmin = await IsUserAdmin();

            return View(products);
        }




        public async Task<IActionResult> Add()
        {
            if (!await IsUserAdmin())  // Kiểm tra quyền Admin
            {
                TempData["ErrorMessage"] = "Bạn không có quyền truy cập!";
                return RedirectToAction(nameof(Index));
            }

            ViewBag.Categories = new SelectList(await _categoryRepository.GetAllAsync(), "Id", "Name_");
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Add(Product product, IFormFile? imageFile, string? imageUrl)
        {
            if (!ModelState.IsValid)
            {
                ViewBag.Categories = new SelectList(await _categoryRepository.GetAllAsync(), "Id", "Name_");
                return View(product);
            }

            product.ImageUrl = await HandleImageUpload(imageFile, imageUrl);
            await _productRepository.AddAsync(product);
            TempData["SuccessMessage"] = "Thêm sản phẩm thành công!";
            return RedirectToAction(nameof(Index));
        }
        public async Task<IActionResult> Details(int id)
        {
            var product = await _productRepository.GetByIdAsync(id);
            if (product == null)
            {
                TempData["ErrorMessage"] = "Sản phẩm không tồn tại!";
                return RedirectToAction(nameof(Index));
            }

            if (product.CategoryId.HasValue)
            {
                product.Category = await _categoryRepository.GetByIdAsync(product.CategoryId.Value);
            }

            return View(product);
        }

        public async Task<IActionResult> Update(int id)
        {
            if (!await IsUserAdmin())  // Kiểm tra quyền Admin
            {
                TempData["ErrorMessage"] = "Bạn không có quyền truy cập!";
                return RedirectToAction(nameof(Index));
            }

            var product = await _productRepository.GetByIdAsync(id);
            if (product == null) return NotFound();

            ViewBag.Categories = new SelectList(await _categoryRepository.GetAllAsync(), "Id", "Name_", product.CategoryId);
            return View(product);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Update(int id, Product product, IFormFile? imageFile, string? imageUrl)
        {
            if (id != product.Id) return NotFound();

            var existingProduct = await _productRepository.GetByIdAsync(id);
            if (existingProduct == null) return NotFound();

            existingProduct.Name_ = product.Name_;
            existingProduct.Price = product.Price;
            existingProduct.Description_ = product.Description_;
            existingProduct.CategoryId = product.CategoryId;

            existingProduct.ImageUrl = await HandleImageUpload(imageFile, imageUrl, existingProduct.ImageUrl);

            await _productRepository.UpdateAsync(existingProduct);
            TempData["SuccessMessage"] = "Cập nhật sản phẩm thành công!";
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Delete(int id)
        {
            if (!await IsUserAdmin())  // Kiểm tra quyền Admin
            {
                TempData["ErrorMessage"] = "Bạn không có quyền truy cập!";
                return RedirectToAction(nameof(Index));
            }

            var product = await _productRepository.GetByIdAsync(id);
            if (product == null)
            {
                TempData["ErrorMessage"] = "Sản phẩm không tồn tại!";
                return RedirectToAction(nameof(Index));
            }

            return View(product);
        }

        [HttpPost, ActionName("DeleteConfirmed")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var product = await _productRepository.GetByIdAsync(id);
            if (product == null)
            {
                TempData["ErrorMessage"] = "Sản phẩm không tồn tại!";
                return RedirectToAction(nameof(Index));
            }

            await _productRepository.DeleteAsync(id);
            TempData["SuccessMessage"] = "Xóa sản phẩm thành công!";
            return RedirectToAction(nameof(Index));
        }

        private async Task<string?> HandleImageUpload(IFormFile? imageFile, string? imageUrl, string? existingImageUrl = null)
        {
            if (imageFile != null && imageFile.Length > 0)
            {
                string uniqueFileName = $"{Guid.NewGuid()}_{Path.GetFileName(imageFile.FileName)}";
                string uploadFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "images");

                if (!Directory.Exists(uploadFolder))
                {
                    Directory.CreateDirectory(uploadFolder);
                }

                string filePath = Path.Combine(uploadFolder, uniqueFileName);

                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    await imageFile.CopyToAsync(fileStream);
                }

                return $"/images/{uniqueFileName}";
            }

            if (!string.IsNullOrEmpty(imageUrl))
            {
                return imageUrl;
            }

            return existingImageUrl;
        }
    }
}
