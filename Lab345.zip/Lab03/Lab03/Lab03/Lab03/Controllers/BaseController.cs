﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;
using Lab03.Models;

namespace Lab03.Controllers
{
    public class BaseController : Controller
    {
        protected readonly UserManager<ApplicationUser> _userManager;
        protected readonly SignInManager<ApplicationUser> _signInManager;

        public BaseController(UserManager<ApplicationUser> userManager, SignInManager<ApplicationUser> signInManager)
        {
            _userManager = userManager;
            _signInManager = signInManager;
        }

        // Hàm kiểm tra nếu user là Admin
        protected async Task<bool> IsUserAdmin()
        {
            var currentUser = await _userManager.GetUserAsync(User);
            return currentUser != null && await _userManager.IsInRoleAsync(currentUser, "Admin");
        }
    }
}
