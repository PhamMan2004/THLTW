﻿using Lab03.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace Lab03.Controllers.Admin // KHÔNG dùng Area
{
    [Authorize(Roles = "Admin")]
    public class UserController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;

        public UserController(UserManager<ApplicationUser> userManager)
        {
            _userManager = userManager;
        }
        [HttpPost]
        public async Task<IActionResult> ToggleRole(string userId)
        {
            var user = await _userManager.FindByIdAsync(userId);
            if (user == null) return NotFound();

            var roles = await _userManager.GetRolesAsync(user);
            var currentRole = roles.FirstOrDefault();

            if (currentRole == "Admin")
            {
                await _userManager.RemoveFromRoleAsync(user, "Admin");
                await _userManager.AddToRoleAsync(user, "User");
            }
            else
            {
                await _userManager.RemoveFromRolesAsync(user, roles); // Xoá hết vai trò cũ
                await _userManager.AddToRoleAsync(user, "Admin");
            }

            TempData["SuccessMessage"] = "Cập nhật quyền thành công!";
            return RedirectToAction("Index");
        }
        [HttpPost]
        public async Task<IActionResult> Delete(string userId)
        {
            var user = await _userManager.FindByIdAsync(userId);
            if (user == null)
            {
                TempData["ErrorMessage"] = "Người dùng không tồn tại.";
                return RedirectToAction("Index");
            }

            // Không cho xóa chính mình (nếu muốn)
            if (user.Email == User.Identity?.Name)
            {
                TempData["ErrorMessage"] = "Bạn không thể xóa chính mình.";
                return RedirectToAction("Index");
            }

            // Xóa user
            var result = await _userManager.DeleteAsync(user);
            if (result.Succeeded)
            {
                TempData["SuccessMessage"] = "Đã xóa người dùng thành công.";
            }
            else
            {
                TempData["ErrorMessage"] = "Xóa thất bại: " + string.Join("; ", result.Errors.Select(e => e.Description));
            }

            return RedirectToAction("Index");
        }

        // Hiển thị form chỉnh sửa
        [HttpGet]
        public async Task<IActionResult> Edit(string userId)
        {
            var user = await _userManager.FindByIdAsync(userId);
            if (user == null) return NotFound();

            return View("~/Views/Admin/User/Edit.cshtml", user);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(ApplicationUser model)
        {
            var user = await _userManager.FindByIdAsync(model.Id);
            if (user == null) return NotFound();

            user.FullName = model.FullName;
            await _userManager.UpdateAsync(user);

            TempData["SuccessMessage"] = "Cập nhật thành công!";
            return RedirectToAction("Index");
        }


        public async Task<IActionResult> Index()
        {
            var users = _userManager.Users.ToList();
            var userRoles = new Dictionary<string, string>();

            foreach (var user in users)
            {
                var roles = await _userManager.GetRolesAsync(user);
                userRoles[user.Id] = roles.FirstOrDefault() ?? "User";
            }

            ViewBag.UserRoles = userRoles;

            // Vì bạn KHÔNG dùng Area, nên cần chỉ định đúng đường dẫn view
            return View("~/Views/Admin/User/Index.cshtml", users);
        }
    }
}
