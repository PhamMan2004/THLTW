﻿using Lab03.Models;
using Lab03.Repository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Lab03.Controllers
{
    [Authorize]
    public class CartController : Controller
    {
        private readonly IProductRepository _productRepo;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly ApplicationDbContext _context;

        public CartController(IProductRepository productRepo, UserManager<ApplicationUser> userManager, ApplicationDbContext context)
        {
            _productRepo = productRepo;
            _userManager = userManager;
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            var user = await _userManager.GetUserAsync(User);
            var cart = await _context.Carts
                .Include(c => c.CartItems)
                .ThenInclude(i => i.Product)
                .FirstOrDefaultAsync(c => c.UserId == user.Id);

            return View(cart?.CartItems ?? new List<CartItem>());
        }

        [HttpPost]
        public async Task<IActionResult> AddToCart(int id)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return Json(new { success = false });

            var product = await _productRepo.GetByIdAsync(id);
            if (product == null) return Json(new { success = false });

            var cart = await _context.Carts
                .Include(c => c.CartItems)
                .FirstOrDefaultAsync(c => c.UserId == user.Id);

            if (cart == null)
            {
                cart = new Cart { UserId = user.Id };
                _context.Carts.Add(cart);
                await _context.SaveChangesAsync(); // cần Save để lấy được CartId
            }

            var item = cart.CartItems.FirstOrDefault(i => i.ProductId == id);
            if (item != null)
            {
                item.Quantity++;
            }
            else
            {
                cart.CartItems.Add(new CartItem
                {
                    ProductId = id,
                    Quantity = 1,
                    UnitPrice = product.Price
                });
            }

            await _context.SaveChangesAsync();
            int itemCount = cart.CartItems.Sum(i => i.Quantity);

            return Json(new { success = true, itemCount });
        }

        [HttpPost]
        public async Task<IActionResult> Remove(int id)
        {
            var user = await _userManager.GetUserAsync(User);
            var cart = await _context.Carts
                .Include(c => c.CartItems)
                .FirstOrDefaultAsync(c => c.UserId == user.Id);

            var item = cart?.CartItems.FirstOrDefault(i => i.ProductId == id);
            if (item != null)
            {
                cart.CartItems.Remove(item);
                await _context.SaveChangesAsync();
            }

            TempData["SuccessMessage"] = "Đã xóa sản phẩm khỏi giỏ hàng.";
            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<IActionResult> Checkout()
        {
            var user = await _userManager.GetUserAsync(User);
            var cart = await _context.Carts
                .Include(c => c.CartItems)
                .ThenInclude(i => i.Product)
                .FirstOrDefaultAsync(c => c.UserId == user.Id);

            if (cart == null || !cart.CartItems.Any())
            {
                TempData["ErrorMessage"] = "Giỏ hàng trống.";
                return RedirectToAction("Index");
            }

            ViewBag.CartItems = cart.CartItems;
            return View(); // View có form nhập địa chỉ và QR
        }

        // Cập nhật phương thức UpdateQuantity để đảm bảo tính năng hoạt động đúng
        [HttpPost]
        public async Task<IActionResult> UpdateQuantity(int productId, int quantity)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return Json(new { success = false });

            // Lấy giỏ hàng của người dùng
            var cart = await _context.Carts
                .Include(c => c.CartItems)
                .FirstOrDefaultAsync(c => c.UserId == user.Id);

            if (cart == null) return Json(new { success = false });

            // Tìm sản phẩm trong giỏ hàng
            var cartItem = cart.CartItems.FirstOrDefault(i => i.ProductId == productId);
            if (cartItem != null)
            {
                // Cập nhật số lượng sản phẩm nếu số lượng hợp lệ
                cartItem.Quantity = quantity < 1 ? 1 : quantity; // Đảm bảo số lượng >= 1
                await _context.SaveChangesAsync(); // Lưu thay đổi vào cơ sở dữ liệu
            }

            // Tính lại tổng số lượng sản phẩm trong giỏ hàng
            int itemCount = cart.CartItems.Sum(i => i.Quantity);

            // Tính lại tổng tiền giỏ hàng
            var total = cart.CartItems.Sum(i => i.Quantity * i.UnitPrice);

            // Trả về thông tin cập nhật cho frontend
            return Json(new { success = true, itemCount, total });
        }

        [HttpPost]
        public async Task<IActionResult> Checkout(string ShippingAddress)
        {
            if (string.IsNullOrEmpty(ShippingAddress))
            {
                TempData["ErrorMessage"] = "Vui lòng nhập địa chỉ giao hàng.";
                return RedirectToAction("Checkout");
            }

            var user = await _userManager.GetUserAsync(User);
            var cart = await _context.Carts
                .Include(c => c.CartItems)
                .FirstOrDefaultAsync(c => c.UserId == user.Id);

            if (cart == null || !cart.CartItems.Any())
            {
                TempData["ErrorMessage"] = "Giỏ hàng trống.";
                return RedirectToAction("Index");
            }

            var order = new Order
            {
                UserId = user.Id,
                ShippingAddress = ShippingAddress,
                OrderDate = DateTime.Now,
                Status = "Đang chờ xác nhận"
            };

            foreach (var item in cart.CartItems)
            {
                order.OrderDetails.Add(new OrderDetail
                {
                    ProductId = item.ProductId,
                    Quantity = item.Quantity,
                    UnitPrice = item.UnitPrice
                });
            }

            _context.Orders.Add(order);
            _context.CartItems.RemoveRange(cart.CartItems);
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = "🧾 Đơn hàng đã được gửi. Vui lòng chờ xác nhận từ Admin.";
            return RedirectToAction("Index", "Product");
        }
    }
}
