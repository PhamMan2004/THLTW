﻿using System.Diagnostics;
using Lab03.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Lab03.Repository;

namespace Lab03.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ICategoryRepository _categoryRepository;
        private readonly IProductRepository _productRepository;

        public HomeController(ILogger<HomeController> logger, ICategoryRepository categoryRepository, IProductRepository productRepository)
        {
            _logger = logger;
            _categoryRepository = categoryRepository;
            _productRepository = productRepository;
        }

        public async Task<IActionResult> Index(int? categoryId)
        {
            var categories = await _categoryRepository.GetAllAsync() ?? new List<Category>();
            ViewBag.Categories = categories;

            var products = await _productRepository.GetAllAsync() ?? new List<Product>();

            if (categoryId.HasValue)
            {
                products = products.Where(p => p.CategoryId == categoryId).ToList();
            }

            foreach (var product in products)
            {
                var category = categories.FirstOrDefault(c => c.Id == product.CategoryId);
                product.CategoryName = category?.Name_ ?? "Không có";
            }

            return View(products);
        }
    }
}
